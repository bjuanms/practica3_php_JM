<?php
$nombrearchivo = "datos.txt";
$archivo = fopen($nombrearchivo, "r"); //la w write y la append(añadir más texto)
fpassthru($archivo);


 ?>