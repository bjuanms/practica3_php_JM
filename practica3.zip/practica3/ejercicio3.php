<?php
//print "<pre>"; print_r($_REQUEST); print "</pre>\n";

$radio=($_REQUEST['radio']);
$menu=($_REQUEST['menu']);
$matriculado=isset($_REQUEST['matriculado']);
if (isset($_REQUEST['nombre'])){
    $nombre=trim(strip_tags($_REQUEST["nombre"]));
}
else{
    $nombre ="";
}
if (isset($_REQUEST['telefono'])){
    $telefono=trim(strip_tags($_REQUEST["telefono"]));
}
else{
    $telefono ="";
}
if ($nombre =="" | $telefono =="" ){
    print "<p> Hay campos sin rellenar.</p>\n";
}
elseif($radio ==""){
    print "<p>No has seleccionado la enseñanza</p>\n";
}
else{
    if ($menu == "Por Pantalla"){
        if ($matriculado == "1"){
            print "<p>El alumno ". $nombre .", con teléfono " . $telefono .", está matriculado en ". $radio .
            ".</p>"; 
        }
        else{
            print "<p>El alumno ". $nombre .", con teléfono " . $telefono .", no está matriculado en ". $radio .
            ".</p>"; 
        }
    }
    else{
        $nombrearchivo = "datos.txt";
        $archivo = fopen($nombrearchivo, "w"); 
        if ($matriculado == "1"){
            fwrite($archivo,"El alumno ". $nombre .", con teléfono " . $telefono .", está matriculado en ". $radio .
            ".");
            fclose($archivo);
        }
        else{
            fwrite($archivo,"El alumno ". $nombre .", con teléfono " . $telefono .", no está matriculado en ". $radio .
            ".");
            fclose($archivo);
        }
        echo '<a href="http://localhost/ejercicios/practica3/mostrardatos.php">Mostrar el archivo</a>' ;
    }
    
}







?>