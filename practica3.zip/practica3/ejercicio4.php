
<form action='ejercicio4.php' method='post'>
<h2>Agenda Virtual PHP</h2>
<h1 >Contactos</h1>
<p>Para guardar presione el botón</p>
<p><Label>Nombre:</label>
<input type="text" size="30" name="nombre"></p>
<p><Label>Trabajo:</label>
<input type="text" size="30" name="trabajo"></p>
<p><Label>Teléfono:</label>
<input type="text" size="30" name="telefono"></p>
<p><Label>Direccion:</label>
<input type="text" size="30" name="direccion"></p>
<p><Label>Otras:</label>
<input type="text" size="30" name="otras"></p>
<p><input type="submit" name="guardar" value="Guardar!"> <input type="reset" name="reset" value="reset"></p>

<p><Label>Buscar por nombre de contacto:</label>
<input type="text" size="30" name="texto"></p>
<p><input type="submit" name="buscar" value="Buscar"></p>
<p><Label>Mostrar todos los contactos:</label>
<input type="submit" name="mostrar" value="Mostrar"></p>
<hr>
</form>

<?php 
//print "<pre>"; print_r($_REQUEST); print "</pre>\n";
if (isset($_REQUEST['guardar'])){
    
    if (isset($_REQUEST['nombre'])){
        $nombre=trim(strip_tags($_REQUEST["nombre"]));
    }
    else{
        $nombre ="";
    }
    if (isset($_REQUEST['trabajo'])){
    $trabajo=trim(strip_tags($_REQUEST["trabajo"]));
    }
    else{
    $trabajo ="";
    }
    if (isset($_REQUEST['telefono'])){
        $telefono=trim(strip_tags($_REQUEST["telefono"]));
        }
    else{
        $telefono ="";
        }
    if (isset($_REQUEST['direccion'])){
            $direccion=trim(strip_tags($_REQUEST["direccion"]));
            }
    else{
            $direccion ="";
            }
    if (isset($_REQUEST['otras'])){
                $otras=trim(strip_tags($_REQUEST["otras"]));
                }
    else{
             $otras ="";
    }
    if ($nombre =="" | $telefono =="" | $trabajo =="" | $direccion =="" | $otras ==""){
        print "<p>El contacto no se ha guardado. Hay campos sin rellenar.</p>\n";
    } 
    else{
        $archivo = "contactos.txt";
        $nombre_archivo = fopen($archivo, "a");
        $nuevo_contacto = ["$nombre",";","$trabajo",";","$telefono",";","$direccion",";","$otras"];
        for($i = 0; $i<=count($nuevo_contacto); $i++)
        {
        fwrite($nombre_archivo,$nuevo_contacto[$i] . " " );

        }
        fwrite($nombre_archivo,PHP_EOL); //hace un salto
        fclose($nombre_archivo);
        echo "El contacto se ha guardado correctamente.";
    }


}
if(isset($_REQUEST['buscar'])){
$texto = $_REQUEST['texto'];
if ($texto == ""){
    echo "No se ha buscado nada";
}
elseif ($texto !== ""){
$archivo = "contactos.txt";
$fd = fopen($archivo, "r");

while( ($linea=fgets($fd)) !== false){ #fgets coge las lineas. fgetc coge caracter a caracter
    //estructura de los datos: codigo_equipo_acb, nombre_equipo, ciudad
    $arrayDatos = explode(";",$linea);
    
    $nombre_cont= $arrayDatos[0];
    $trabajo_cont = $arrayDatos[1];
    $telefono_cont = $arrayDatos[2];
    $direccion_cont = $arrayDatos[3];
    $otras_cont = $arrayDatos[4];
    if(trim($nombre_cont)== trim($texto)){ //saca solo las lineas cuya nombre sea el buscado.
        echo " Nombre: $nombre_cont <br> ";
        echo " Trabajo: $trabajo_cont <br>";
        echo " Teléfono: $telefono_cont <br>";
        echo " Dirección: $direccion_cont <br>";
        echo " Otras: $otras_cont ";
    }
    }
    fclose($fd);
}

//if (trim($nombre_cont) !== trim($texto)){
    //echo "No se ha encontrado el contacto buscado   ";
//}

}
if (isset($_REQUEST['mostrar'])){
    $archivo = "contactos.txt";
    $fd = fopen($archivo, "r");

    while( ($linea=fgets($fd)) !== false){ 
        $arrayDatos = explode(";",$linea);
        $nombre_cont= $arrayDatos[0];
        $trabajo_cont = $arrayDatos[1];
        $telefono_cont = $arrayDatos[2];
        $direccion_cont = $arrayDatos[3];
        $otras_cont = $arrayDatos[4];
        
        echo " Nombre: $nombre_cont <br> ";
        echo " Trabajo: $trabajo_cont <br>";
        echo " Teléfono: $telefono_cont <br>";
        echo " Dirección: $direccion_cont <br>";
        echo " Otras: $otras_cont <br><br>";
        }
    
    fclose($fd);
}
?>



