
<?php
print"<p>Ejercicio2: Uso de Números Aleatorios y vectores en php</p>\n";
print"<p><b>Jugador 1</b></p>\n";

for ($i1 = 0; $i1 < 5; $i1++){
$dado1 = rand(1,6);
print"<img src='./img/$dado1.jpg' width=100 height=100>\n";
$sum1=$dado1++;
}
print"<p><b>Jugador 2</b></p>\n";

for ($i2 = 0; $i2 < 5; $i2++){
$dado2 = rand(1,6);
print"<img src='./img/$dado2.jpg' width=100 height=100>\n";
$sum2=$dado2++;
}

if ($sum1 > $sum2){
    print"<p>En conjunto, ha ganado el jugador 1</p>\n";
}
else{
    print"<p>En conjunto, ha ganado el jugador 2</p>\n";
}

?>


