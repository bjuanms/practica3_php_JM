
<html><head></head>
<style>
    .fieldset{
       background: purple;
    }
</style>
<body>
<fieldset> <!--recuadra el contenido -->
<legend>Formulario</legend><!--nombre del recuadro -->
	<form>
        <p>Escriba el ancho y el alto (0 < números <=100) y se mostrará un rectangulo de estrellas de ese tamaño</p>
	<p><b>Ancho:</b> <input type="text" name="nombre" ></p>  
	<p><b>Alto:</b> <input type="text" name="nombre" ></p> 
    <br>
    <p><input type='submit' value='Dibujar'></p>
    <p><input type='Borrar' value='reset'></p>
	
	</fieldset>
<?php
$alto=rand(5,10);
$ancho=rand(5,10);

print"<p>\n<h1>cuadrado</h1>  ";
for ($i =1; $i <= $alto; $i++){
    for ($j=1; $j<=$ancho; $j++){
        print "* ";
    }
    print"<br>";
}
print"</p>\n";
print"\n";
?>
<p><input type='submit' value='Calcular'></p>


</body>
</html>
<!--LO
$a= rand(1,9);
$b= rand(1,9);
print "<input type='text' name='num1' value=$a>\n";
print "<br><br>";
print "X <input type='text' name='num2' value=$b>\n";
print "<hr with=30>\n";
print "<input type='text' name='sol'>\n";
?>
<p><input type='submit' value='Corregir'>
<input type='reset' value='Borrar'></p>

LO QUE HAY QUE CAMBIAR PARA VER LOS DISTINTOS RESULTADOS ES SÓLO EL ACTION. EL FORMULARIO SE PUEDE USAR
    MUCHAS VECES CAMBIANDO ESTE PARÁMETRO-->