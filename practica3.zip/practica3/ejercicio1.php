
<html>
	<head></head>
<style>
    #fieldset{
        background:#e6e6ff;
        border-color: purple;
    }
</style>
<body>  
<form action='ejercicio1.php' method='post'>
<fieldset id=fieldset> <!--recuadra el contenido -->
<legend>Formulario</legend><!--nombre del recuadro -->
	<form>
        <p>Escriba el ancho y el alto (0 < números <=100) y se mostrará un rectangulo de estrellas de ese tamaño</p>
	<p><b>Ancho:</b> <input type="text" name="ancho" ></p>  
	<p><b>Alto:</b> <input type="text" name="alto" ></p> 
    <br>
    <p><input type='submit' value='Dibujar'>  <input type='reset' value='borrar'></p>
	
	</fieldset>
</body>

<?php
if (isset($_REQUEST['ancho'])){
    $ancho=trim(strip_tags($_REQUEST["ancho"]));
}
else{
    $ancho ="";
}
if (isset($_REQUEST['alto'])){
    $alto=trim(strip_tags($_REQUEST["alto"]));
}
else{
    $alto ="";
}
if ($ancho =="" | $alto ==""){
    print "<p> Hay campos sin rellenar.</p>\n";
}
else{
print"<p> Ancho: $ancho <br>
Alto: $alto <br>  ";
for ($i =1; $i <= $alto; $i++){
    for ($j=1; $j<=$ancho; $j++){
        print "* ";
    }
    print"<br>";
}
print"</p>\n";
print"\n";
}
?>


</html>